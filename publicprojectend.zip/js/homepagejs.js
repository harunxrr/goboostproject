const click = document.querySelector("#toggle");
const menu = document.querySelector("#openermenu");
const bars = document.querySelector("#bars");
click.addEventListener("click",()=>{
menu.classList.toggle("openermenu");
click.classList.toggle("navbar-icon__animate");
bars.classList.toggle("navbar-icon__animate");
bars.classList.toggle("bi-x");
});

window.addEventListener("resize",()=>{
    const getwidthonlyscreen=window.innerWidth;
    if (getwidthonlyscreen>998){
        menu.classList.remove("openermenu");
        bars.classList.remove("bi-x");
    }
    else {
    }
})

